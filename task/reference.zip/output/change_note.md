# 回调验签Secret轮换

周四维护窗先使用preload阶段同时挂载新旧两代Secret，再由activate阶段启用新钥。旧签名观察期结束后才进入retire阶段。

Chart只引用平台密钥组登记的Secret，不创建Secret对象，也不读取密钥正文。发布评审人核对rendered与reports，维护窗值班负责现场应用、验签观察和回滚。

activate阶段出现异常时，使用preload阶段values和清单回滚。Secret创建、权限与密钥正文仍由平台密钥组处理。
