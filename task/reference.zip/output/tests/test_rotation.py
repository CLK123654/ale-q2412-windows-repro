import csv
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class RotationTests(unittest.TestCase):
    def test_validation(self):
        data = json.loads((ROOT / "results/validation.json").read_text(encoding="utf-8"))
        self.assertEqual(data["result"], "PASS")
        self.assertTrue(all(data["checks"].values()))

    def test_reference_is_external(self):
        with (ROOT / "results/rotation_ledger.csv").open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual([int(row["secret_count"]) for row in rows], [1, 2, 2, 1])
        for row in rows:
            render = (ROOT / "results" / f"render-{row['phase']}.yaml").read_text(encoding="utf-8")
            self.assertNotIn("kind: Secret", render)
            for name in row["secret_names"].split("|"):
                self.assertIn(f"name: {name}", render)

    def test_negative_cases(self):
        with (ROOT / "results/negative_cases.csv").open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(len(rows), 2)
        self.assertTrue(all(int(row["exit_code"]) != 0 for row in rows))


if __name__ == "__main__":
    unittest.main()
