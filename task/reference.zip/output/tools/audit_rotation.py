from __future__ import annotations

import csv
import json
import os
import re
import shutil
import subprocess
from pathlib import Path


INPUT = Path(os.environ["ALE_INPUT_ROOT"]).resolve()
ROOT = Path(os.environ["ALE_REFERENCE_ROOT"]).resolve()
CHART = ROOT / "charts/callback-keyring"
OUT = Path(os.environ.get("ALE_RESULTS_ROOT", ROOT / "results")).resolve()
HELM = os.environ["HELM_BIN"]

INVENTORY_FIELDS = ["key_id", "secret_name", "status", "not_before_utc", "not_after_utc"]
PHASE_FIELDS = ["phase", "sequence", "rotation_revision", "active_key", "accepted_keys", "expected_secret_count"]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read_csv(path: Path, fields: list[str]) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        require(reader.fieldnames == fields, f"{path.name}: header mismatch")
        return list(reader)


contract = json.loads((INPUT / "rotation_contract.json").read_text(encoding="utf-8"))
inventory_rows = read_csv(INPUT / "key_inventory.csv", INVENTORY_FIELDS)
phase_rows = read_csv(INPUT / "phase_plan.csv", PHASE_FIELDS)
require([row["key_id"] for row in inventory_rows] == ["g17", "g18"], "inventory IDs")
secret_refs = {row["key_id"]: row["secret_name"] for row in inventory_rows}
require(all(secret_refs.values()), "empty Secret name")
require([row["phase"] for row in phase_rows] == contract["phases_in_order"], "phase order")

lint = subprocess.run([HELM, "lint", str(CHART), "--strict"], text=True, capture_output=True, timeout=30)
require(lint.returncode == 0, lint.stdout + lint.stderr)

staging = OUT.parent / f".{OUT.name}.staging"
if staging.exists():
    shutil.rmtree(staging)
staging.mkdir(parents=True)

try:
    ledger: list[dict[str, object]] = []
    for row in phase_rows:
        phase = row["phase"]
        accepted = row["accepted_keys"].split("|")
        require(row["active_key"] in accepted, f"{phase}: active key")
        require(all(key in secret_refs for key in accepted), f"{phase}: unknown key")
        values = CHART / f"values-{phase}.yaml"
        run = subprocess.run(
            [HELM, "template", "callback", str(CHART), "--namespace", contract["namespace"], "--values", str(values)],
            text=True,
            capture_output=True,
            timeout=30,
        )
        require(run.returncode == 0, run.stderr)
        require("kind: Secret" not in run.stdout, f"{phase}: chart created Secret")
        projected = re.findall(r"(?m)^\s+name: (callback-keyring-g\d+)$", run.stdout)
        expected_names = [secret_refs[key] for key in accepted]
        require(projected == expected_names, f"{phase}: projected Secret names")
        require(f'activeKey: "{row["active_key"]}"' in run.stdout, f"{phase}: active key output")
        require(f'rotationRevision: "{row["rotation_revision"]}"' in run.stdout, f"{phase}: revision output")
        (staging / f"render-{phase}.yaml").write_text(run.stdout, encoding="utf-8")
        ledger.append({
            "phase": phase,
            "sequence": row["sequence"],
            "rotation_revision": row["rotation_revision"],
            "active_key": row["active_key"],
            "accepted_keys": row["accepted_keys"],
            "secret_names": "|".join(expected_names),
            "secret_count": len(expected_names),
            "object_count": len(re.findall(r"(?m)^kind: ", run.stdout)),
            "projected_paths": "|".join(f"{key}.key" for key in accepted),
        })

    fields = list(ledger[0])
    with (staging / "rotation_ledger.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(ledger)

    negatives = []
    for case, token in [("gap", "must appear in acceptedKeys"), ("unknown", "missing from secretRefs")]:
        values = CHART / f"values-{case}.yaml"
        run = subprocess.run([HELM, "template", "callback", str(CHART), "--namespace", contract["namespace"], "--values", str(values)], text=True, capture_output=True, timeout=30)
        require(run.returncode != 0 and not run.stdout.strip() and token in run.stderr, f"negative case {case}")
        negatives.append({"case": case, "values_file": values.name, "exit_code": run.returncode, "stdout_empty": "true", "diagnostic_token": token})
    with (staging / "negative_cases.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(negatives[0]))
        writer.writeheader()
        writer.writerows(negatives)

    checks = {
        "helm_lint_passes": True,
        "four_phase_order_is_exact": [row["phase"] for row in ledger] == ["steady", "preload", "activate", "retire"],
        "secret_reference_wave_is_1_2_2_1": [row["secret_count"] for row in ledger] == [1, 2, 2, 1],
        "active_key_is_always_accepted": all(row["active_key"] in row["accepted_keys"].split("|") for row in ledger),
        "chart_creates_no_secret_objects": all("kind: Secret" not in (staging / f"render-{row['phase']}.yaml").read_text(encoding="utf-8") for row in ledger),
        "projected_sources_match_inventory": all(row["secret_names"] == "|".join(secret_refs[key] for key in row["accepted_keys"].split("|")) for row in ledger),
        "two_negative_cases_fail_closed": len(negatives) == 2,
    }
    validation = {"result": "PASS" if all(checks.values()) else "FAIL", "controls": {"phase_rows": len(ledger), "negative_rows": len(negatives)}, "checks": checks}
    require(validation["result"] == "PASS", "runtime checks")
    (staging / "validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if OUT.exists():
        shutil.rmtree(OUT)
    staging.rename(OUT)
    print(json.dumps(validation, ensure_ascii=False, sort_keys=True))
finally:
    if staging.exists():
        shutil.rmtree(staging)
