# 使用说明

chart保存完整HelmChart，rendered保存各轮换阶段清单，reports连接阶段计划与Secret登记，change_note.md记录维护窗和回滚分工。
